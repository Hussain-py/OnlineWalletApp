package org.cap.demo.model;

public enum AccountType {
	SAVINGS,
	CURRENT,
	LOAN,
	SALARY

}
