package org.cap.demo.model;

public enum TransactionType {
	CREDIT,DEBIT;
}
