package com.capgemini.training.businessbean;

import static org.junit.Assert.*;

import org.junit.Test;
import com.capgemini.training.UI.UITester;
import com.capgemini.training.service.WalletService;
import com.capgemini.training.service.WalletServiceImpl;

import com.capgemini.training.businessbean.CustomerMaster;


import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.mockStatic;



import java.sql.SQLException;
//import java.time.LocalDate;
import org.junit.Test;
import org.mockito.MockedStatic;




public class WalletApplicationTest {
 


	WalletService Ws = mock(WalletServiceImpl.class);
	UITester ui = mock(UITester.class);
	

	// GetAccountNumber Testing
	@Test
	public void GetAccountNumber_Test1() throws ClassNotFoundException, SQLException {
		System.out.println("Testing to get account number which exists ");
		assertEquals(UITester.getAccountNo("Test4", "Test4"), 74379);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.getAccountNo("Test4", "Test4")).thenReturn(74379);
			assertEquals(UITester.getAccountNo("Test4", "Test4"), 74379);
		}
	}


	@Test
	public void GetAccountNumber_Test2() throws ClassNotFoundException, SQLException {
		System.out.println("Testing to get account number which does not exists ");
		assertEquals(UITester.getAccountNo("test6", "test6"), 0);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.getAccountNo("test6", "test6")).thenReturn(0);
			assertEquals(UITester.getAccountNo("test6", "test6"), 0);
		}
	}


	//Create Account Testing
	@Test
	public void createAccount_Test1() throws ClassNotFoundException,SQLException { 
		System.out.println("Testing for Creation of new Account");

		try(MockedStatic<UITester> ui = mockStatic(UITester.class)){ ui.when(()->
		UITester.createAccount("Testnew2", "Testnew2",8866556677l)).thenReturn(true);
		assertEquals(UITester.createAccount("Testnew2", "Testnew2", 8866556677l), true);
		}
	}


	// Here give the info which is not present in database
	@Test
	public void createAccount_Test2() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for Creation of Account which is already exists");
		assertEquals(UITester.createAccount("Capgemini", "Capgemini", 9856765443l), false);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.createAccount("Capgemini", "Capgemini", 9856765443l)).thenReturn(false);
			assertEquals(UITester.createAccount("Capgemini", "Capgemini", 9856765443l), false);
		} // Already exists
	}


	// Login Method Testing
	@Test
	public void login_Test1() throws ClassNotFoundException, SQLException {
		System.out.println(" Testing for Login Account which exists");
		assertEquals(UITester.Login("Test4", "Test4"), true);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.Login("Test4", "Test4")).thenReturn(true);
			assertEquals(UITester.Login("Test4", "Test4"), true);
		}
	}

	@Test
	public void login_Test2() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for Login Account which is not exists");
		assertEquals(false, UITester.Login("Test44", "Test44"));

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.Login("Test44", "Test44")).thenReturn(false);
			assertEquals(false, UITester.Login("Test44", "Test44"));
		}
	}



	// AddMoney
	@Test
	public void addMoney_Test1() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for AddMoney Unsuccessful");
		assertEquals(UITester.AddMoney(7437449, 1000), false);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.AddMoney(7437449, 1000)).thenReturn(false);
			assertEquals(UITester.AddMoney(7437449, 1000), false);
			System.out.println("Account not found");
		}
	}

	@Test
	public void addMoney_Test2() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for AddMoney Successful");
		assertEquals(UITester.AddMoney(74379, 2000), true);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.AddMoney(74379, 2000)).thenReturn(true);
			assertEquals(UITester.AddMoney(74379, 2000), true);
		}
	}


	// DepositMoney

	@Test
	public void makedeposit_Test1() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for Deposit Unsuccessful");
		assertEquals(UITester.deposit(53794658, 100), false);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.deposit(537946518, 100)).thenReturn(false);
			assertEquals(UITester.deposit(537946518, 100), false);
			System.out.println("Account not found");
		}
	}

	@Test
	public void makedeposit_Test2() throws ClassNotFoundException, SQLException, Exception {
		System.out.println("Testing for Deposit Successful");
		assertEquals(UITester.deposit(81626, 100), true);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.deposit(81626, 100)).thenReturn(true);
			assertEquals(UITester.deposit(81626, 100), true);
		}
	}


	@Test
	public void makedeposit_Test3() throws ClassNotFoundException, SQLException, Exception {
		System.out.println("Testing for Deposit Successful");
		assertEquals(UITester.deposit(74379, 100), true);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.deposit(74379, 100)).thenReturn(true);
			assertEquals(UITester.deposit(74379, 100), true);
		}
	}


	// WithdrawalMoney
	@Test
	public void withdrawMoney_Test1() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for withdraw Successful");
		assertEquals(UITester.withdrawMoney(81626, 100), true);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.withdrawMoney(81626, 100)).thenReturn(true);
			assertEquals(UITester.withdrawMoney(81626, 100), true);
		}
	}



	@Test
	public void withdrawMoney_Test2() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for withdraw Unsuccessful");
		assertEquals(UITester.withdrawMoney(98230, 100), false);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.withdrawMoney(98230, 100)).thenReturn(false);
			assertEquals(UITester.withdrawMoney(98230, 100), false);
			System.out.println("Account not found");
		}
	}



	@Test
	public void withdraw_Test3() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for withdraw Unsuccessful");
		assertEquals(UITester.withdrawMoney(52131783, 40), false);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.withdrawMoney(52131783, 40)).thenReturn(false);
			assertEquals(UITester.withdrawMoney(52131783, 40), false);
			System.out.println("Account not found");
		}
	}



	// TransferMoney
	@Test
	public void TransferMoney_Test1() throws ClassNotFoundException, SQLException {
		// description: if send_ac and rec_ac is correct and money transfer successful
		System.out.println("Testing for Transfer Money Successful");
		assertEquals(UITester.TransferMoney(81626, 100, 74379), true);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.TransferMoney(81626, 100, 74379)).thenReturn(true);
			assertEquals(UITester.TransferMoney(81626, 100, 74379), true);
		}
	}



	@Test
	public void TransferMoney_Test2() throws ClassNotFoundException, SQLException {
		// description: if receiver account number is Wrong then pass
		System.out.println("Testing for Transfer Money Unsuccessful");
		assertEquals(UITester.TransferMoney(816268, 100, 74379), false);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.TransferMoney(816268, 100, 74379)).thenReturn(false);
			assertEquals(UITester.TransferMoney(816268, 100, 74379), false);
			System.out.println("Account not found");
		}
	}



	@Test
	public void transfer_money_Test3() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for Transfer Money Unsuccessful");
		assertEquals(UITester.TransferMoney(887788, 1000, 8877588), false);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.TransferMoney(887788, 1000, 8877588)).thenReturn(false);
			assertEquals(UITester.TransferMoney(887788, 1000, 8877588), false);
			System.out.println("Account not found");
		}
	}



	@Test
	public void transfer_money_Test4() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for Transfer Money Successful");
		assertEquals(UITester.TransferMoney(81626, 100, 81626), true);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.TransferMoney(81626, 100, 81626)).thenReturn(true);
			assertEquals(UITester.TransferMoney(81626, 100, 81626), true);
			//System.out.println("Account not found");
		}
	}



	// ViewTransaction
	@Test
	public void View_Transaction_Test1() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for last 10 transaction : ");
		assertEquals(UITester.ViewLast10Transaction(88776655), false);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.ViewLast10Transaction(88776655)).thenReturn(false);
			assertEquals(UITester.ViewLast10Transaction(88776655), false);
			System.out.println("Account not found");
		}
	}



	@Test
	public void View_Transaction_Test2() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for last 10 transaction : ");
		assertEquals(UITester.ViewLast10Transaction(17854), false);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.ViewLast10Transaction(17854)).thenReturn(false);
			assertEquals(UITester.ViewLast10Transaction(17854), false);
			// No transactions done yet!!..
		}
	}



	@Test
	public void View_Transaction_Test3() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for last 10 transaction : ");
		assertEquals(UITester.ViewLast10Transaction(81626), true);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.ViewLast10Transaction(81626)).thenReturn(true);
			assertEquals(UITester.ViewLast10Transaction(81626), true);
		}
	}



	@Test
	public void View_Transaction_Test4() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for view last 10 transaction ");
		assertEquals(UITester.ViewLast10Transaction(63744), true);
		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.ViewLast10Transaction(63744)).thenReturn(true);
			assertEquals(UITester.ViewLast10Transaction(63744), true);
		}
	}



	//	@Test
	//	public void View_Transaction_Test5() throws ClassNotFoundException, SQLException {
	//		System.out.println("Testing for last 10 transaction : ");
	//		assertEquals(UITester.viewTransactions(1241902672), true);
	//		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
	//			ui.when(() -> UITester.viewTransactions(1241902672)).thenReturn(true);
	//			assertEquals(UITester.viewTransactions(1241902672), true);
	//		}
	//	}



	// TransactionOnParticularDate
	@Test
	public void transactionOnParticularDate_Test1() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for display transaction on particular date");
		assertEquals(UITester.particularTransaction(81626, "2022-01-20"), true);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.particularTransaction(81626, "2022-01-20")).thenReturn(true);
			assertEquals(UITester.particularTransaction(81626, "2022-01-20"), true);
		}
	}


	@Test
	public void transactionOnParticularDate_Test2() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for display transaction on particular date");
		assertEquals(UITester.particularTransaction(87831, "2022-01-20"), false);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.particularTransaction(87831, "2022-01-20")).thenReturn(false);
			assertEquals(UITester.particularTransaction(87831, "2022-01-20"), false);
			System.out.println("Account not found");
		}
	}



	@Test
	public void view_trans_on_date_Test3() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for display transaction on particular date");
		assertEquals(UITester.particularTransaction(63744, "2022-01-20"), true);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.particularTransaction(63744, "2022-01-20")).thenReturn(true);
			assertEquals(UITester.particularTransaction(63744, "2022-01-20"), true);
		}
	}



	@Test
	public void view_trans_on_date_Test4() throws ClassNotFoundException, SQLException {
		System.out.println("Testing for display transaction on particular date");
		assertEquals(UITester.particularTransaction(63744, ""), false);

		try (MockedStatic<UITester> ui = mockStatic(UITester.class)) {
			ui.when(() -> UITester.particularTransaction(63744, "")).thenReturn(false);
			assertEquals(UITester.particularTransaction(63744, ""), false);
			System.out.println("Account not found");
		}
	}
	
	CustomerMaster customer = new CustomerMaster(12408,"Test4",8888120639l);
	AccountMaster account = new AccountMaster(95514, 10043, 1000, "2022-01-20","Test8");


	//Test Customer Master Class
	@Test
	public void CustomerMaster_Test1() throws ClassNotFoundException, SQLException {
		System.out.println("Testing to get Name from CustomerMaster class ");		
		assertEquals(customer.getName(), "Test4");
	} 
	@Test
	public void CustomerMaster_Test2() throws ClassNotFoundException, SQLException {
		System.out.println("Testing to get contact_number from CustomerMaster class ");		
		assertEquals(customer.getCustomer_contact_number(), 8888120639l);
	} 
	
	
	//Test Account Master Class
	@Test
	public void AccountMaster_Test1() throws ClassNotFoundException, SQLException {
		System.out.println("Testing to get Contact Number from CustomerMaster class ");		
		assertEquals(account.getPassword(), "Test8");

	}


	@Test
	public void AccountMaster_Test3() throws ClassNotFoundException, SQLException {
		System.out.println("Testing to get Contact Number from CustomerMaster class ");		
		assertEquals(account.getAccount_opening_date(), "2022-01-20");

	}
}
