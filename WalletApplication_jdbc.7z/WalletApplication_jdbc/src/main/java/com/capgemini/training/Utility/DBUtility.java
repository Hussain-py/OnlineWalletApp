package com.capgemini.training.Utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
 
public class DBUtility { 
	public static final String url = "jdbc:mysql://localhost:3306/onlinewallet";
	public static final String username = "root";
	public static final String password = "Hu$$@!n88";
	private static Connection connection = null;
	
 
	public static Connection getDBConnection() throws ClassNotFoundException, SQLException {
		connection = DriverManager.getConnection(url, username, password);
		return connection;
	}

	public static void getDBConnectionClose() throws SQLException {
		connection.close();
	}

}