package com.capgemini.training.businessbean;

public class CustomerMaster {
	private Integer customer_id;
	private String Name;
	private long customer_contact_number;

	public CustomerMaster() {
	}

	public CustomerMaster(Integer customer_id, String name, long customer_contact_number) {
		super();
		this.customer_id = customer_id;
		Name = name;
		this.customer_contact_number = customer_contact_number;
	}
  
	public Integer getCustomer_id() {
		return customer_id;
	} 

	public void setCustomer_id(Integer customer_id) {
		this.customer_id = customer_id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public long getCustomer_contact_number() {
		return customer_contact_number;
	}

	public void setCustomer_contact_number(long customer_contact_number) {
		this.customer_contact_number = customer_contact_number;
	}
}
