package com.capgemini.training.service;

import java.sql.SQLException;

import com.capgemini.training.businessbean.AccountMaster;
import com.capgemini.training.businessbean.CustomerMaster;
import com.capgemini.training.businessbean.TransactionDetails;
import com.capgemini.training.dao.WalletDAO;
import com.capgemini.training.dao.WalletDAOImpl;

public class WalletServiceImpl implements WalletService{

	WalletDAO wDAO = new WalletDAOImpl();

	@Override
	public boolean createAccount(CustomerMaster c,AccountMaster a) throws ClassNotFoundException, SQLException{
		boolean res = false;
		try {
			res = wDAO.createAccount(c,a);
			System.out.println(res); 
			if(res)
				System.out.println("Account created success fully");
			else
				System.out.println("Account not created successfully");

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			throw e;
		}
		return res;
	} 

	@Override
	public boolean transactionOnParticularDate(AccountMaster a,TransactionDetails T) throws ClassNotFoundException, SQLException {
		boolean res = false;
		try {
			 res = wDAO.transactionOnParticularDate(a,T);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} catch(Exception e) {
			throw e;
		}
		return res;
	}
	
	@Override
	public boolean ViewTransaction(AccountMaster a)throws ClassNotFoundException, SQLException {
		boolean rs = false;
		try {
			rs = wDAO.ViewTransaction(a);
		}catch (ClassNotFoundException | SQLException e) {
			System.out.println(e+e.getMessage()+" duplicate 3");
		} catch (Exception e) {
			throw e;
		}
		return rs;
	}
	
	@Override
	public boolean login(CustomerMaster c,AccountMaster a)throws ClassNotFoundException, SQLException{
		boolean res = false; 
		try {
			res = wDAO.login(c, a); 
			System.out.println("login Service :"+res);
			if(res == true)
				System.out.println("Logged in");
			else
				System.out.println("The username or password invalid");
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			throw e;
		}
		return res;
	}
	
	@Override
	public int getAccountNumber(CustomerMaster c,AccountMaster a)throws ClassNotFoundException, SQLException{
		int acNo=0;

		try {
			acNo = wDAO.getAccountNumber(c, a);
		}catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			throw e;
		}
		return acNo;
	}
	


	@Override
	public boolean deposit(AccountMaster a, double depositamount) throws ClassNotFoundException, SQLException{
		boolean res=false;
		try {
			res =wDAO.deposit( a,depositamount);
			System.out.println(res);
			if(res)
				System.out.println("Amount Deposited successfully");
			else
				System.out.println("Deposit Unsuccessfully");
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} catch(Exception e) {
			throw e;
		}
		return res;
	}

	@Override
	public boolean withdrawMoney(AccountMaster a, double amount)throws SQLException, ClassNotFoundException {
		// TODO Auto-generated method stub
		boolean res=false;

		try {
			res = wDAO.withdrawMoney(a, amount);
			if(res)
				System.out.println("Money withdraw successfully");
			else
				System.out.println("Money not withdraw successfully");

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			throw e;
		}
		return res;
	}

	@Override
	public boolean transferMoney(AccountMaster a, double amount, int rec_ac_no) throws ClassNotFoundException, SQLException
	{
		boolean res = false;
		try {
			res = wDAO.transferMoney(a,amount,rec_ac_no);
			if(res)
				System.out.println("amount transfer succesfully");
			else
				System.out.println("there is a error while transfering amount");

		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			throw e;
		}
		return res;
	}

	@Override
	public boolean addMoney(AccountMaster a, double amount)throws SQLException, ClassNotFoundException {
		boolean res = false;
		try {
			res = wDAO.addMoney(a, amount);
			if(res)
				System.out.println("Money added to wallet successfully");
			else
				System.out.println("Money not added successfully");

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			throw e;
		}
		return res;
	}
	
	@Override
	public double showBalance(CustomerMaster c, AccountMaster a) throws ClassNotFoundException, SQLException {
		double balance = 0.0;
		try {
			balance = wDAO.showBalance(c, a);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage());
		} catch (Exception e) {
			throw e;
		}
		return balance;
	}



}
