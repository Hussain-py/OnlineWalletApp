package com.capgemini.training.businessbean;

public class TransactionDetails {
	private Integer transaction_number;
	private Integer transaction_id;
	private Integer account_number;
	private String date_of_transaction;
	private Integer transaction_amount;
	private String transaction_type;

	public Integer getTransaction_number() {
		return transaction_number;
	}
  
	public void setTransaction_number(Integer transaction_number) {
		this.transaction_number = transaction_number;
	}

	public Integer getTransaction_id() {
		return transaction_id;
	}
 
	public void setTransaction_id(Integer transaction_id) {
		this.transaction_id = transaction_id;
	}

	public Integer getAccount_number() {
		return account_number;
	}

	public void setAccount_number(Integer account_number) {
		this.account_number = account_number;
	}

	public String getDate_of_transaction() {
		return date_of_transaction;
	}

	public void setDate_of_transaction(String date_of_transaction) {
		this.date_of_transaction = date_of_transaction;
	}

	public Integer getTransaction_amount() {
		return transaction_amount;
	}

	public void setTransaction_amount(Integer transaction_amount) {
		this.transaction_amount = transaction_amount;
	}

	public String getTransaction_type() {
		return transaction_type;
	}

	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}

}
