package com.capgemini.training.businessbean;

public class AccountMaster {
	private Integer account_number;
	private Integer customer_id;
	private double balance;
	private String account_opening_date;
	private String password;
	private Integer amt;

	public AccountMaster() {
	}
 
	public AccountMaster(Integer account_number, Integer customer_id, double balance, String account_opening_date,String password) {
		this.account_number = account_number;
		this.customer_id = customer_id;
		this.balance = balance;
		this.account_opening_date = account_opening_date;
		this.password = password;

	}

	public AccountMaster(Integer account_number) {
		this.account_number = account_number;
	}

	public Integer getAccount_number() {
		return account_number;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setAccount_number(Integer account_number) {
		this.account_number = account_number;
	}

	public Integer getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(Integer customer_id) {
		this.customer_id = customer_id;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getAccount_opening_date() {
		return account_opening_date;
	}

	public void setAccount_opening_date(String account_opening_date) {
		this.account_opening_date = account_opening_date;
	}

	public double getamt() {
		return amt;
	}

	public void setamt(int amt) {
		this.amt = amt;
	}

}
