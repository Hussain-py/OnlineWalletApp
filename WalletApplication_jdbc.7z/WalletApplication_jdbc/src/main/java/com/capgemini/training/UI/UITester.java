package com.capgemini.training.UI;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import com.capgemini.training.businessbean.AccountMaster;
import com.capgemini.training.businessbean.CustomerMaster;
import com.capgemini.training.businessbean.TransactionDetails;
import com.capgemini.training.service.WalletService;
import com.capgemini.training.service.WalletServiceImpl;


public class UITester {
 

	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		AccountMaster a = new AccountMaster();

		try {	 
			ExecutorService executorService = Executors.newSingleThreadExecutor();
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int ch = 0;
			do{
				System.out.println("******************************************");
				System.out.println("\n ===> Welcome to Online Wallet <===== \n");
				System.out.println("******************************************");
				System.out.println("1.Create Account\n2.Login\n3.Cancel");
				String name;
				String pass_code; 
				int inch =0;
				System.out.print("\n Enter Input:"); // user input
				ch = Integer.parseInt(br.readLine());
				switch (ch) {
				case 1:
					System.out.print("Enter Unique UserName:");
					name = br.readLine();
					System.out.print("Enter New Password:");
					pass_code = br.readLine();
					System.out.println("Enter mobile number: ");
					Long mNo = Long.parseLong(br.readLine());
					createAccount(name,pass_code,mNo);
					break;
				case 2:
					System.out.print("Enter your UserName:");
					name = br.readLine();
					System.out.print("Enter your Password:");
					pass_code = br.readLine();
					boolean cont = Login(name,pass_code);
					if(cont==true) {

						do{

							System.out.println("\n1.AddMoney\n2.Transfer money\n3.Withdraw Amount"
									+ "\n4.Deposit\n5.View last 10 transaction\n6.See transaction on particular date"
									+ "\n7.Logout");
							int acNo=getAccountNo(name,pass_code);
							System.out.println("Enter your Choice");
							inch = Integer.parseInt(br.readLine());
							int amt=0;
							if(inch>0&&inch<5) {
								
								System.out.println("Enter amount : ");
								amt =Integer.parseInt(br.readLine());
								a.setamt(amt);

							}
							switch(inch) {
							case 1:
								
								System.out.println("fetching your current balance,Please Wait...");
								Runnable task = new Runnable() {

									@Override
									public void run() {
										try {
											TimeUnit.SECONDS.sleep(2);
										} catch (InterruptedException e) {
											System.out.println("InterruptedException handled");
										}
										AddMoney(acNo,a.getamt());
										System.out.print("Your current balance is: "+showBalance(name, pass_code));
									}
								};
								executorService.submit(task);
								Thread.sleep(5000);
								break;
							case 2:
								try {
									System.out.println("Enter receivers account number");
									int racNo = Integer.parseInt(br.readLine());

									Runnable task1 = new Runnable() {
										@Override
										public void run() {
											try {
												TimeUnit.SECONDS.sleep(2);
											} catch (InterruptedException e) {
												System.out.println("InterruptedException handled");
											}
											TransferMoney(acNo,a.getamt(),racNo);
											System.out.println("Your current balance is: ");
											System.out.println(showBalance(name, pass_code));

										}
									};
									executorService.submit(task1);

								} catch (Exception e) {
									System.out.println("Invalid reciever account number");
								}
								Thread.sleep(4000);
								break;

							case 3:
								try {
									Runnable task2 = new Runnable() {
										@Override
										public void run() {
											try {
												TimeUnit.SECONDS.sleep(2);
											} catch (InterruptedException e) {
												System.out.println("InterruptedException handled");
											}
											//TransferMoney(acNo,a.getamt(),racNo);
											double crblc = showBalance(name, pass_code);
											if(crblc>a.getamt()) {
												withdrawMoney(acNo,a.getamt());
												System.out.println("Your current balance is: "+showBalance(name, pass_code));
											}else {
												System.out.println("You don't have enough balance");
												System.out.println("Your current balance is: "+showBalance(name, pass_code));

											}
										}
									};
									executorService.submit(task2);

								} catch (Exception e) {
									System.out.println("Invalid reciever account number");
								}
								Thread.sleep(4000);
								break;


							case 4:
								try {
									Runnable task3 = new Runnable() {
										@Override
										public void run() {
											try {
												TimeUnit.SECONDS.sleep(2);
											} catch (InterruptedException e) {
												System.out.println("InterruptedException handled");
											}
											deposit(acNo,a.getamt());
											System.out.println("Your current balance is: "+showBalance(name, pass_code));
							
										}
									};
									executorService.submit(task3);

								} catch (Exception e) {
									System.out.println("Invalid reciever account number");
								}
								Thread.sleep(4000);
								break;
							case 5:
								ViewLast10Transaction(acNo);
								break; 
							case 6:
								System.out.println("Enter date Ex. YYYY-MM-DD format");
								String date = br.readLine();
								particularTransaction(acNo,date);
								break;
							case 7:
								System.out.println("Logout Successfully!\n\n Thank You");
								System.exit(0);

							default:
								System.out.println("Invalid option please select correct option");
								break;
							}
						}while(inch>0);

					}		
					break;
				case 3:
					System.out.println("Exited Successfully!\n\n Thank You :)");
					System.exit(0);
				default:
					System.out.println("Invalid Entry!\n");
				}
			}while(ch>0);
			br.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}




	public static boolean createAccount(String name,String pswd,Long mobileNo) {
		boolean rs = false;
		try {
			WalletService wService = new WalletServiceImpl();
			AccountMaster a = new AccountMaster();
			CustomerMaster c = new CustomerMaster(); 
			a.setPassword(pswd);
			c.setName(name);
			c.setCustomer_contact_number(mobileNo);
			rs = wService.createAccount(c, a);
		}catch (ClassNotFoundException | SQLException e) {
			//e.printStackTrace();
			System.out.println(e.getMessage()+ "duplicate");
		} catch (Exception e) {
			//e.printStackTrace();
			System.out.println(e.getMessage()+"duplicate 2");
		}
		return rs;
	}


	//Login Function
	public static boolean Login(String name, String pswd) {
		boolean res=false;
		try {
			WalletService wService = new WalletServiceImpl();
			AccountMaster a = new AccountMaster();
			CustomerMaster c = new CustomerMaster();
			a.setPassword(pswd);
			c.setName(name);
			res = wService.login(c, a);

		}catch (ClassNotFoundException | SQLException e) {
			//e.printStackTrace();
			System.out.println(e.getMessage()+ "duplicate");
		} catch (Exception e) {
			//e.printStackTrace();
			System.out.println(e.getMessage()+"duplicate 2");
		}
		return res;
	}


	public static boolean particularTransaction(int acNo,String date) {
		//Read Transaction of Particular Date
		boolean res =false;

		try {
			WalletService wService = new WalletServiceImpl();
			AccountMaster a = new AccountMaster();

			TransactionDetails T = new TransactionDetails();
			a.setAccount_number(acNo);

			T.setDate_of_transaction(date);

			res = wService.transactionOnParticularDate(a,T);

		} catch (ClassNotFoundException | SQLException e) {
			//e.printStackTrace();
			System.out.println(e.getMessage());
		} catch (Exception e) {
			//e.printStackTrace();
			System.out.println(e.getMessage());
		}
		return res;
	}


	//View Last 10 Transaction
	public static Boolean ViewLast10Transaction(int acno) {
		Boolean res=false;

		try {
			WalletService wService = new WalletServiceImpl();
			AccountMaster a = new AccountMaster();
			//a.setAccount_number(1418557552);
			a.setAccount_number(acno);
			res = wService.ViewTransaction(a);
		}
		catch (ClassNotFoundException | SQLException e) {
			//e.printStackTrace();
			System.out.println(e.getMessage()+ "duplicate");
		}catch(Exception e) {
			e.printStackTrace();
		}
		return res;	
	} 

	//DepositMoney
	public static boolean deposit(int acNo,double d) {
		boolean res=false;
		try {
			WalletService wService = new WalletServiceImpl();
			AccountMaster a = new AccountMaster();
			a.setAccount_number(acNo);
			res = wService.deposit(a, d);
		}
		catch (ClassNotFoundException | SQLException e) {
			//e.printStackTrace();
			System.out.println(e.getMessage()+ "duplicate");
		}catch(Exception e) {
			e.printStackTrace();
		}
		return res;	
	}

	//withdrawMoney
	public static boolean withdrawMoney(int acNo,double d) {
		boolean res=false;
		try {

			WalletService wService = new WalletServiceImpl();
			AccountMaster a = new AccountMaster();
			a.setAccount_number(acNo);
			res = wService.withdrawMoney(a, d);

		}
		catch (ClassNotFoundException | SQLException e) {
			//e.printStackTrace();
			System.out.println(e.getMessage()+ "duplicate");
		}catch(Exception e) {
			e.printStackTrace();
		}
		return res;	
	}


	//Transfer
	public static boolean TransferMoney(int acNo,double d, int racNo) {
		boolean res = false;
		try {
			AccountMaster a = new AccountMaster();
			a.setAccount_number(acNo);			
			WalletService wService = new WalletServiceImpl();

			//			int amount=200;
			//			a.setAccount_number(1145862995);
			//			int rec_ac_no=1729719955;
			res = wService.transferMoney(a,d,racNo);

		}
		catch (ClassNotFoundException | SQLException e) {
			//e.printStackTrace();
			System.out.println(e.getMessage()+ "duplicate");
		}catch(Exception e) {
			e.printStackTrace();
		}
		return res;	
	}


	//AddMonyaddMoney
	public static boolean AddMoney(int acNo,double d) {
		boolean res=false;
		try {

			WalletService wService = new WalletServiceImpl();	
			AccountMaster a = new AccountMaster();
			a.setAccount_number(acNo);
			res = wService.addMoney(a,d);

		}
		catch (ClassNotFoundException | SQLException e) {
			//e.printStackTrace();
			System.out.println(e.getMessage()+ "duplicate");
		}catch(Exception e) {
			e.printStackTrace();
		}
		return res;	
	}


	public static int getAccountNo(String usrnm, String pswd) {
		int acn=0;
		try {
			WalletService wService = new WalletServiceImpl();
			AccountMaster a = new AccountMaster();
			CustomerMaster c = new CustomerMaster();
			a.setPassword(pswd);
			c.setName(usrnm);
			acn = wService.getAccountNumber(c, a);
		}catch (ClassNotFoundException | SQLException e) {
			//e.printStackTrace();
			System.out.println(e.getMessage()+ "duplicate");
		}catch(Exception e) {
			e.printStackTrace();
		}
		return acn;
	}


	public static double showBalance(String usrnm, String pswd) {
		double balance=00.00;
		try {
			WalletService wService = new WalletServiceImpl();
			AccountMaster a = new AccountMaster();
			CustomerMaster c = new CustomerMaster();
			a.setPassword(pswd);
			c.setName(usrnm);
			balance = wService.showBalance(c, a);
		} catch (ClassNotFoundException | SQLException e) {
			System.out.println(e.getMessage() + "duplicate");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return balance;

	}
}

