package com.capgemini.training.dao;


import java.sql.SQLException;

import com.capgemini.training.businessbean.AccountMaster;
import com.capgemini.training.businessbean.CustomerMaster;
import com.capgemini.training.businessbean.TransactionDetails;

public interface WalletDAO {
	public boolean createAccount(CustomerMaster c,AccountMaster a)throws ClassNotFoundException, SQLException ;
	public boolean transactionOnParticularDate(AccountMaster a, TransactionDetails T) throws ClassNotFoundException, SQLException;
	public boolean ViewTransaction(AccountMaster a) throws ClassNotFoundException, SQLException;
	public boolean login(CustomerMaster c,AccountMaster a)throws ClassNotFoundException, SQLException;
	public boolean withdrawMoney(AccountMaster a, double amount) throws SQLException, ClassNotFoundException;
	public boolean transferMoney(AccountMaster a,double amount,int rec_ac_no)throws ClassNotFoundException, SQLException;
	public boolean addMoney(AccountMaster a, double amount) throws SQLException, ClassNotFoundException;
	public boolean deposit(AccountMaster a, double depositamount) throws ClassNotFoundException, SQLException;
	public int getAccountNumber(CustomerMaster c,AccountMaster a)throws ClassNotFoundException, SQLException;
	public double showBalance(CustomerMaster c, AccountMaster a) throws ClassNotFoundException, SQLException;


}