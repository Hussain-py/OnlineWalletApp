package com.capgemini.training.dao;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;

import com.capgemini.training.Utility.DBUtility;
import com.capgemini.training.businessbean.AccountMaster;
import com.capgemini.training.businessbean.CustomerMaster;
import com.capgemini.training.businessbean.TransactionDetails;

public class WalletDAOImpl implements WalletDAO {
	private static Connection connection = null;
	private static Statement statement = null;

	static Integer generateRandomDigits() {
		int random_acc_no = 10000 + new Random().nextInt(90000);
		return random_acc_no;
	}

	static int generateRandomId() {
		int random_id = 10000 + new Random().nextInt(9000);
		return random_id;
	}
 
	public boolean createAccount(CustomerMaster c, AccountMaster a) throws ClassNotFoundException, SQLException	{
		String insertdata;
		int d1 = 0, d2=0;
		try {

			String name = c.getName();
			long Number = c.getCustomer_contact_number();
			String paswrd = a.getPassword();
			Integer accNo = generateRandomDigits();
			int id = generateRandomId();

			connection = DBUtility.getDBConnection();
			statement = connection.createStatement();

			insertdata = "insert into customer_master values(" + id + ",'" + name + "','" + Number + "')";
			d1=statement.executeUpdate(insertdata);

			insertdata = "insert into account_master values(" + accNo + "," + id + ",1000,'" + LocalDate.now() + "','"
					+ paswrd + "')";

			d2 = statement.executeUpdate(insertdata);
		} catch (Exception e) {
			throw e;
		}
		if (d1>0 & d2>0) {
			return true;
		} else {
			return false;
		}

	}

	public boolean ViewTransaction(AccountMaster a) throws ClassNotFoundException, SQLException {
		String retrieveData;
		boolean res = false;
		int ds = 0;
		try {
			Integer acNo = a.getAccount_number();
			connection = DBUtility.getDBConnection();
			statement = connection.createStatement();
			System.out.println("The last 10 transactions are :");
			retrieveData = "Select * from Transaction_details where account_number =" + acNo
					+ " order by transaction_number desc limit 10";
			ResultSet resultSet = statement.executeQuery(retrieveData);
			res = resultSet.next();
			System.out.println(
					"----------------------------------------------------------------------------------------------------");
			System.out.printf("%-15s%-15s%-15s\t%-15s\t\t%-15s\t%-15s\n", "Trans_no", "Trans_id", "Account_No",
					"date_Of_Trans", "Trans_amt", "Trans_type");
			System.out.println(
					"----------------------------------------------------------------------------------------------------");

			while (resultSet.next()) {
				System.out.println("   " + resultSet.getInt("transaction_number") + "\t\t "
						+ resultSet.getString("transaction_id") + " \t\t" + resultSet.getString("account_number")
						+ "\t\t " + resultSet.getString("date_of_transaction") + "\t\t "
						+ resultSet.getDouble("transaction_amount") + "\t\t" + resultSet.getString("transaction_type"));

			}

		} catch (Exception e) {
			throw e;
		}

		return res;
	}

	@Override
	public boolean transactionOnParticularDate(AccountMaster a, TransactionDetails T)
			throws ClassNotFoundException, SQLException {
		boolean res = false;
		try {
			int account_number = a.getAccount_number();
			String Date = T.getDate_of_transaction();

			String str1 = String.format(
					"SELECT * FROM transaction_details where account_number= %d and date_of_transaction = '%s' ",
					account_number, Date);
			String retrievedata = str1;
			connection = DBUtility.getDBConnection();
			statement = connection.createStatement();

			ResultSet resultSet = statement.executeQuery(retrievedata);
			System.out.println("Retrieveing Query executed!!");
			res = resultSet.next();
			System.out.println(res);
			System.out.println(
					"----------------------------------------------------------------------------------------------------");
			System.out.printf("%-15s%-15s%-15s\t%-15s\t\t%-15s\t%-15s\n", "Trans_no", "Trans_id", "Account_No",
					"date_Of_Trans", "Trans_amt", "Trans_type");
			System.out.println(					"----------------------------------------------------------------------------------------------------");
			while (resultSet.next()) {
				System.out.println(" " + resultSet.getInt("transaction_number") + "\t\t "
						+ resultSet.getString("transaction_id") + " \t\t" + resultSet.getString("account_number")
						+ "\t\t " + resultSet.getString("date_of_transaction") + "\t\t "
						+ resultSet.getDouble("transaction_amount") + "\t\t" + resultSet.getString("transaction_type"));
			}

		} catch (Exception e) {
			throw e;
		} finally {
			DBUtility.getDBConnectionClose();
		}
		return res;
	}

	public boolean login(CustomerMaster c, AccountMaster a) throws ClassNotFoundException, SQLException {
		int ds = 0, ds1 = 0;
		ResultSet r1, r2;
		try {
			String name = c.getName();
			String pswd = a.getPassword();
			String str = "Select customer_id from customer_master where first_name = '" + name + "'";
			connection = DBUtility.getDBConnection();
			statement = connection.createStatement();
			r1 = statement.executeQuery(str);
			if (r1.next())
				ds = r1.getInt("customer_id");
			str = "Select customer_id from account_master where password = '" + pswd + "'";
			r2 = statement.executeQuery(str);
			if (r2.next())
				ds1 = r2.getInt("customer_id");

		} catch (Exception e) {
			throw e;
		}
		if (ds > 0 & ds1 > 0)
			return true;
		else
			return false;
	}

	public boolean addMoney(AccountMaster a, double amount) throws SQLException, ClassNotFoundException {
		int ac_no = a.getAccount_number();
		String sql;
		String sql2;
		int b = 0;

		try {
			connection.setAutoCommit(false);
			sql = "select * from account_master where account_number=" + ac_no;
			PreparedStatement ps = connection.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();

			Statement st = connection.createStatement();

			int randonTransId = generateRandomDigits();
			connection.setSavepoint();

			sql = "update account_master set balance=balance+" + amount + " where account_number=" + ac_no;
			b = statement.executeUpdate(sql);

			sql2 = "insert into transaction_details (transaction_id, account_number, date_of_transaction, transaction_amount, transaction_type) values ("
					+ randonTransId + ", " + ac_no + ", curdate(), " + amount + ",'Credit')";
			statement.executeUpdate(sql2);

			if (b > 0) {
				System.out.println("Amount credited!");
				connection.commit();
			}
		} catch (Exception e) {
			e.printStackTrace();
			connection.rollback();
		}
		if (b > 0) {
			return true;
		} else {
			return false;
		}
	}

	// New deposit Function
	public boolean deposit(AccountMaster a, double depositamount) throws ClassNotFoundException, SQLException // create
	// account
	// function
	{
		String insertdata;
		int data = 0;
		int accNo = a.getAccount_number();

		try {

			int id = generateRandomId();
			connection = DBUtility.getDBConnection();
			statement = connection.createStatement();

			insertdata = "update account_master set balance=balance+" + depositamount + " where account_number="
					+ accNo;
			statement.executeUpdate(insertdata);

			insertdata = "insert into transaction_details (transaction_id, account_number, date_of_transaction, transaction_amount, transaction_type) values ("
					+ id + ", " + accNo + ", curdate(), " + depositamount + ",'Deposited')";
			data = statement.executeUpdate(insertdata);
		} catch (Exception e) {
			throw e;
		}
		if (data > 0) {
			return true;
		} else {
			return false;
		}

	}

	// New withdrawMoney Function
	public boolean withdrawMoney(AccountMaster a, double amount) throws ClassNotFoundException, SQLException{
		String insertdata;
		int data = 0;

		int accNo = a.getAccount_number();
		try {
			String paswrd = a.getPassword();
			int id = generateRandomId();

			connection = DBUtility.getDBConnection();
			statement = connection.createStatement();

			insertdata = "update account_master set balance=balance-" + amount + " where account_number=" + accNo;

			statement.executeUpdate(insertdata);

			insertdata = "insert into transaction_details (transaction_id, account_number, date_of_transaction, transaction_amount, transaction_type) values ("
					+ id + ", " + accNo + ", curdate(), " + amount + ",'Debited')";
			data = statement.executeUpdate(insertdata);
		} catch (Exception e) {
			throw e;
		}
		if (data > 0) {
			return true;
		} else {
			return false;
		}
	}

	public int getAccountNumber(CustomerMaster c, AccountMaster a) throws ClassNotFoundException, SQLException {
		int ds = 0, ds1 = 0;
		Integer acNo = 0;
		ResultSet r1, r2;
		try {
			String name = c.getName();
			String pswd = a.getPassword();
			String str = "Select customer_id from customer_master where first_name = '" + name + "'";
			connection = DBUtility.getDBConnection();
			statement = connection.createStatement();
			r1 = statement.executeQuery(str);
			if (r1.next())
				ds = r1.getInt("customer_id");
			str = "Select customer_id from account_master where password = '" + pswd + "'";
			r2 = statement.executeQuery(str);
			if (r2.next())
				;
			ds1 = r2.getInt("customer_id");
			if (ds == ds1) {
				str = "Select account_number from account_master where customer_id =" + ds;
				ResultSet r3 = statement.executeQuery(str);
				if (r3.next())
					;
				acNo = Integer.parseInt(r3.getString("account_number"));
				a.setAccount_number(acNo);
			}

		} catch (Exception e) {
			throw e;
		}
		return acNo;
	}



	public boolean transferMoney(AccountMaster a, double amount, int rec_ac_no)
			throws ClassNotFoundException, SQLException {
		String insertdata;
		int ds = 0;
		try {
			Integer send_ac_no = a.getAccount_number();
			double balance = 0;
			String str = "Select balance from account_master where account_number=" + send_ac_no;

			connection = DBUtility.getDBConnection();
			statement = connection.createStatement();
			ResultSet r3 = statement.executeQuery(str);
			if (r3.next())
				;
			balance = r3.getDouble("balance");
			if (balance < amount) {
				System.out.println("Insufficient Account Balance");
				return false;
			}
			insertdata = "update account_master set balance=balance-" + amount + " where account_number=" + send_ac_no;
			statement.executeUpdate(insertdata);
			// credit
			insertdata = "update account_master set balance=balance+" + amount + " where account_number=" + rec_ac_no;
			ds = statement.executeUpdate(insertdata);

		} catch (Exception e) {
			throw e;
		}
		if (ds > 0) {
			return true;
		} else {
			return false;
		}

	}

	public double showBalance(CustomerMaster c, AccountMaster a) throws ClassNotFoundException, SQLException {
		int ds = 0, ds1 = 0;
		double balance = 0.0;
		ResultSet r1, r2;
		try {
			String name = c.getName();
			String pswd = a.getPassword();
			String str = "Select customer_id from customer_master where first_name = '" + name + "'";
			connection = DBUtility.getDBConnection();
			statement = connection.createStatement();
			r1 = statement.executeQuery(str);
			if (r1.next())
				ds = r1.getInt("customer_id");
			str = "Select customer_id from account_master where password = '" + pswd + "'";
			r2 = statement.executeQuery(str);
			if (r2.next())
				;
			ds1 = r2.getInt("customer_id");
			if (ds == ds1) {
				str = "Select balance from account_master where customer_id =" + ds;
				ResultSet r3 = statement.executeQuery(str);
				if (r3.next())
					balance = Integer.parseInt(r3.getString("balance"));
			}

		} catch (Exception e) {
			throw e;
		}
		return balance;
	}

}
