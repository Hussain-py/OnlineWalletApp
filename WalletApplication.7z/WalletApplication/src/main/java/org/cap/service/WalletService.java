package org.cap.service;

import java.util.List;
import java.util.Optional;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public interface WalletService {

	Customer validateLogin(Customer user2);

	//List<String> getAllCities();

	Customer registerCustomer(Customer customer, Address address);
	
	public Account createAccount(Account account);

	public List<Account> finAccountsByCustomer(Customer customer, String str);

//	Account transaction(int accountno, double amount, String transactiontype);
	
	public Account transaction(int accountno, double amount, String transactiontype);


	public Account findAccount(int accountno);


	public List<String> getAllStates();

	public Customer findCustomer(int customerId);

	public List<String> getAllCities();

	public List<Transaction> summaryDisplay(int accountno, String start_date, String end_date);
	
	public List<Account> AccountList(int customer_fk);
	
	public List<Account> getAllAccountByCustomer(int customerId);


	


}
