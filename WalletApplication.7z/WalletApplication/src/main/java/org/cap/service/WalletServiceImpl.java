package org.cap.service;

import java.util.List;
import java.util.Optional;

import org.cap.dao.WalletDao;
import org.cap.dao.WalletDaoImpl;
import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public class WalletServiceImpl implements WalletService {
	private WalletDao walletDao;
	
	public WalletServiceImpl() {
		walletDao=new WalletDaoImpl();
		}
	@Override
	public Customer validateLogin(Customer customer) {
		// TODO Auto-generated method stub
		return walletDao.validateLogin(customer);
	}

	
	@Override
	public Customer registerCustomer(Customer customer, Address address) {

		return walletDao.registerCustomer(customer, address);
	}
	

	@Override
	public List<String> getAllCities() {
		return walletDao.getAllCities();
	}
	
	@Override
	public List<String> getAllStates() {
		return walletDao.getAllStates();
	}

	@Override
	public Customer findCustomer(int customerId) {
		return walletDao.findCustomer(customerId);
	}


	@Override
	public Account createAccount(Account account) {
		return walletDao.createAccount(account);
	}
	
	

	@Override
	public Account findAccount(int accountno) {
		return walletDao.findAccount(accountno);
	}
	
	
	@Override
	public Account transaction(int accountno, double amount, String transactiontype) {
		return walletDao.transaction(accountno, amount, transactiontype);
	}
	@Override
	public List<Account> finAccountsByCustomer(Customer customer, String str) {
		// TODO Auto-generated method stub
		return walletDao.findAccountsByCustomer(customer, str);
	}
	@Override
	public List<Transaction> summaryDisplay(int accountno, String start_date, String end_date) {
		// TODO Auto-generated method stub
		return walletDao.summaryDisplay(accountno,start_date,end_date);
	}
	@Override
	public List<Account> AccountList(int customer_fk) {
		// TODO Auto-generated method stub
		return walletDao.AccountList(customer_fk);
	}
	@Override
	public List<Account> getAllAccountByCustomer(int customerId) {
		// TODO Auto-generated method stub
		return walletDao.getAllAccountByCustomer(customerId);
	}
	
	
	

}
