package org.cap.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.Transaction;
import org.cap.model.TransactionType;

public class WalletDaoImpl implements WalletDao{




	private EntityManager getEntityManager() {
		EntityManagerFactory entityManagerFactory=
				Persistence.createEntityManagerFactory("capg");

		return entityManagerFactory.createEntityManager();
	}


	EntityManager entityManager=getEntityManager();

	@Override
	public Customer registerCustomer(Customer customer, Address address) {

		EntityTransaction entityTransaction=entityManager.getTransaction();
		entityTransaction.begin();

		entityManager.persist(customer); //generate customer ID pk
		address.setCustomer(customer);
		entityManager.persist(address);

		entityTransaction.commit();
		//entityManager.close();
		return customer;
	}


	@Override
	public Customer validateLogin(Customer customer) {


		EntityTransaction entityTransaction= entityManager.getTransaction();
		entityTransaction.begin();

		Query query= entityManager.createQuery("from Customer c where c.emailId=:uname and "
				+ " c.password=:upwd");
		query.setParameter("uname", customer.getEmailId());
		query.setParameter("upwd", customer.getPassword());

		List<Customer> users =query.getResultList();
		if(!users.isEmpty())
			return users.get(0);
		entityTransaction.commit();
		//entityManager.close();
		return null;
	}


	@Override
	public List<String> getAllCities() {

		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		String sql = "select c.cityname from City c";

		List<String> cities = entityManager.createQuery(sql).getResultList();
		if (!cities.isEmpty())
			return cities;
		entityTransaction.commit();
		//entityManager.close();

		return null;
	}

	@Override
	public List<String> getAllStates() {

		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		String sql = "select s.statename from State s ";
		List<String> states = entityManager.createQuery(sql).getResultList();
		if (!states.isEmpty())
			return states;

		entityTransaction.commit();
		//entityManager.close();
		return null;
	}

	@Override
	public Customer findCustomer(int customerId) {

		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();

		Customer customer = entityManager.find(Customer.class, customerId);

		entityTransaction.commit();
		//entityManager.close();
		return customer;
	}

	@Override
	public Account createAccount(Account account) {

		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();

		entityManager.persist(account);

		entityTransaction.commit();
		//entityManager.close();
		return account;
	}


	@Override
	public List<Account> findAccountsByCustomer(Customer customer, String str) {

		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();
		Query query;
		if (str.equalsIgnoreCase("from")) {
			query = entityManager.createQuery("from Account a where a.customer=:customer");
		} else {
			query = entityManager.createQuery("from Account a where a.customer!=:customer");
		}
		query.setParameter("customer", customer);
		List<Account> accounts = query.getResultList();
		if (!accounts.isEmpty())
			return accounts;
		entityTransaction.commit();
		entityManager.close();
		return null;
	}

	@Override
	public Account findAccount(int accountno) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();

		Account account = entityManager.find(Account.class, accountno);

		entityTransaction.commit();
		entityManager.close();
		return account;
	}



	@Override
	public Account transaction(int accountno, double amount, String transactiontype) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();

		Account account = entityManager.find(Account.class, accountno);

		if (transactiontype.equalsIgnoreCase("deposit")) {

			String sql1 = "update Account set balance=balance+" +amount+ " where accountNumber="+accountno;
			Query query1 = entityManager.createQuery(sql1);
			query1.executeUpdate();

			account.setAccountNumber(accountno);
			Transaction transaction = new Transaction(LocalDate.now(),amount,TransactionType.CREDIT,account);
			entityManager.persist(transaction);

		} else {

				String sql1 = "update Account set balance=balance-" +amount+ " where accountNumber="+accountno;
				Query query1 = entityManager.createQuery(sql1);
				query1.executeUpdate();

				account.setAccountNumber(accountno);
				Transaction transaction = new Transaction(LocalDate.now(),amount,TransactionType.DEBIT,account);
				entityManager.persist(transaction);
		}

		entityTransaction.commit();
		entityManager.close();
		return account;
	}


	@Override
	public List<Account> getAllAccountByCustomer(int customerId) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		entityTransaction.begin();

		String sql="from Account a where a.customer=:custId";

		Query query = entityManager.createQuery(sql);
		query.setParameter("custId", customerId);	
		List<Account> accounts= query.getResultList();

		entityTransaction.commit();
		entityManager.close();
		return accounts;
	}


	@Override
	public List<Transaction> summaryDisplay(int accountno, String start_date, String end_date) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		
		entityTransaction.begin();
		
		String sql="from Transaction  where account_fk="+accountno+" and transactionDate between '"+start_date+" ' and  '"+end_date+" '";
		Query query =entityManager.createQuery(sql);
		List<Transaction> Transactionlist = query.getResultList();
		
		if (!Transactionlist.isEmpty())
			return Transactionlist;
	      
		entityTransaction.commit();
		entityManager.close();
		return null;		
	}
	
	@Override
	public List<Account> AccountList(int customer_fk) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();
		Customer customer = new Customer();
		customer.setCustomerId(customer_fk);
		entityTransaction.begin();
		//String sql="from account  where customer_fk="+customer_fk+"";
		String sq = "from Account a where a.customer="+customer;
		Query query =entityManager.createQuery(sq);
		List<Account> Accountlist = query.getResultList();
		
		if (!Accountlist.isEmpty())
			return Accountlist;
	      
		entityTransaction.commit();
		entityManager.close();
		return null;		
	}



}
