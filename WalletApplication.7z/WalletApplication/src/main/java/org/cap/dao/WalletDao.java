package org.cap.dao;

import java.util.List;
import java.util.Optional;

import org.cap.model.Account;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.Transaction;

public interface WalletDao {

	public Customer validateLogin(Customer customer);


	public Customer registerCustomer(Customer customer,Address address);
	
	public List<Account> findAccountsByCustomer(Customer customer, String str);

	public Account createAccount(Account account);

	//public Account transaction(int accountno, double amount, String transactiontype);
	
	public Account transaction(int accountno, double amount, String transactiontype);

	public List<String> getAllCities();

	public List<String> getAllStates();

	public Customer findCustomer(int customerId);

	public Account findAccount(int accountno);


	public List<Account> getAllAccountByCustomer(int customerId);


	public List<Transaction> summaryDisplay(int accountno, String start_date, String end_date);


	public List<Account> AccountList(int customer_fk);

}
