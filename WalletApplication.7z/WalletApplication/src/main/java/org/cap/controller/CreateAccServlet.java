package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.AccountType;
import org.cap.model.Customer;
import org.cap.service.WalletService;
import org.cap.service.WalletServiceImpl;

/**
 * Servlet implementation class CreateAccServlet
 */
@WebServlet("/CreateAccServlet")
public class CreateAccServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private WalletService walletService;

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateAccServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		walletService = new WalletServiceImpl();
		
		
		HttpSession httpSession = request.getSession(true);
		int customerId = Integer.parseInt(httpSession.getAttribute("customerId").toString()) ;
		Account account= new Account();
	
		String accountType = request.getParameter("atype");
//		SAVING,CURRENT,LOAN,SALARY
		if(accountType.equalsIgnoreCase("SAVINGS")) 
			account.setAccountType(AccountType.SAVINGS);
		else if(accountType.equalsIgnoreCase("CURRENT"))
			account.setAccountType(AccountType.CURRENT);
		else if(accountType.equalsIgnoreCase("LOAN"))
			account.setAccountType(AccountType.LOAN);
		else
			account.setAccountType(AccountType.SALARY);
		
		double balance = Double.parseDouble(request.getParameter("balance"));
		account.setBalance(balance);
		
		String desciption = request.getParameter("description");
		account.setDescription(desciption);
		
		Customer customer = walletService.findCustomer(customerId);
		
		
		account.setCustomer(customer);
		
		Account account2= walletService.createAccount(account);
		
		
		if(account2!=null) {
			PrintWriter out = response.getWriter();
//			response.sendRedirect("MainPageServlet");
		}
		
		response.sendRedirect("MainPageServlet");


	}
}
