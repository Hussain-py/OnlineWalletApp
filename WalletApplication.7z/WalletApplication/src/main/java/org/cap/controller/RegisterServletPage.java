package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cap.service.WalletService;
import org.cap.service.WalletServiceImpl;


/**
 * Servlet implementation class RegisterServletPage
 */
@WebServlet("/RegisterServletPage")
public class RegisterServletPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private WalletService walletService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServletPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		walletService=new WalletServiceImpl();
		PrintWriter out=response.getWriter();
		
		//List<String> cities=walletService.getAllCities();
		
		out.println("<!DOCTYPE html>\r\n"
				+ "<html lang=\"en\">\r\n"
				+ "<head>\r\n"
				+ "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\r\n"
				+ "\r\n"
				+ "<title>Registration Page</title>\r\n"
				+ "<script type=\"text/javascript\" src=\"./script/myscript.js\"></script>\r\n"
				+ "<link rel=\"stylesheet\" href=\"./assets/vendors/mdi/css/materialdesignicons.min.css\" >\r\n"
				+ "<link rel=\"stylesheet\" href=\"./assets/vendors/css/vendor.bundle.base.css\" >\r\n"
				+ "<link rel=\"stylesheet\" href=\"./assets/css/style.css\" >\r\n"
				+ "<link rel=\"shortcut icon\" href=\"./assets/images/favicon.ico\" / >\r\n"
				+ "</head>\r\n"
				+ "<body>\r\n"
				+"<div class=\"container-scroller\">"
				+"      <div class=\"container-fluid page-body-wrapper full-page-wrapper\">\r\n"
				+ "        <div class=\"content-wrapper d-flex align-items-center auth\">\r\n"
				+ "          <div class=\"row flex-grow\">\r\n"
				+ "            <div class=\"col-lg-4 mx-auto\">\r\n"
				+ "              <div class=\"auth-form-light text-left p-5\">\r\n"
				+ "                <div class=\"brand-logo\">\r\n"
				+ "                  <img src=\"../../assets/images/logo.svg\">\r\n"
				+ "                </div>\r\n"
				+ "                <h4>New here?</h4>\r\n"
				+ "                <h6 class=\"font-weight-light\">Signing up is easy. It only takes a few steps</h6>\r\n"
				+ "                <form class=\"pt-3\" action=\"./RegisterCustomer\" method=\"post\">\r\n"
				+ "                  <div class=\"form-group\">\r\n"
				+ "                    <input type=\"text\" name=\"firstName\" class=\"form-control form-control-lg\" id=\"exampleInputUsername1\" placeholder=\"FirstName\">\r\n"
				+ "                  </div>\r\n"
				+ "                  <div class=\"form-group\">\r\n"
				+ "                    <input type=\"text\" name=\"lastName\" class=\"form-control form-control-lg\" id=\"exampleInputlastName\" placeholder=\"Last Name\">\r\n"
				+ "                  </div>\r\n"
				+ "                  <div class=\"form-group\">\r\n"
				+ "                    <input type=\"text\" name=\"emailId\" class=\"form-control form-control-lg\" id=\"exampleInputemailId\" placeholder=\"Email\">\r\n"
				+ "                  </div>\r\n"
				+ "                  <div class=\"form-group\">\r\n"
				+ "                    <input type=\"number\" name=\"contactNo\" class=\"form-control form-control-lg\" id=\"exampleInputcontactNo\" placeholder=\"Contact Number\">\r\n"
				+ "                  </div>\r\n"
				+ "                  <div class=\"form-group\">\r\n"
				+ "                    <input type=\"text\" name=\"addressline1\" class=\"form-control form-control-lg\" id=\"exampleInputadd1\" placeholder=\"Address Line1\">\r\n"
				+ "                  </div>\r\n"
				+ "                  <div class=\"form-group\">\r\n"
				+ "                    <input type=\"text\" name=\"addressline2\" class=\"form-control form-control-lg\" id=\"exampleInputadd2\" placeholder=\"Address Line2\">\r\n"
				+ "                  </div>\r\n"
				+"            		<div class=\"form-group\">\r\n"
				+ "                    <select name=\"city\" class=\"form-control form-control-lg\" id=\"exampleFormControlSelect2\">\r\n"
				+ "                      <option>City</option>\r\n"
				+ "                      <option  value=\"Mumbai\">Mumbai</option>\r\n"
				+ "                      <option value=\"Hyderabd\">Hyderabd</option>\r\n"
				+ "                      <option value=\"Bangalore\">Bangalore</option>\r\n"
				+ "                    </select>\r\n"
				+ "                  </div>"
				+"            		<div class=\"form-group\">\r\n"
				+ "                    <select name=\"state\" class=\"form-control form-control-lg\" id=\"exampleFormControlSelect2\">\r\n"
				+ "                      <option>State</option>\r\n"
				+ "                      <option value=\"Maharashtra\">Maharashtra</option>\r\n"
				+ "                      <option value=\"Telangana\">Telangana</option>\r\n"
				+ "                      <option value=\"Karnataka\">Karnataka</option>\r\n"
				+ "                    </select>\r\n"
				+ "                  </div>"
				+ "                  <div class=\"form-group\">\r\n"
				+ "                    <input type=\"text\" name=\"pincode\" class=\"form-control form-control-lg\" id=\"exampleInputUsername1\" placeholder=\"Pincode\">\r\n"
				+ "                  </div>\r\n"
				+ "                  <div class=\"form-group\">\r\n"
				+ "                    <input type=\"password\" name=\"password\" class=\"form-control form-control-lg\" id=\"exampleInputUsername1\" placeholder=\"Password\">\r\n"
				+ "                  </div>\r\n"
				+ "                  <div class=\"form-group\">\r\n"
				+ "						<input type=\"radio\" name=\"gender\" value=\"Male\">Male\r\n"
				+ "						<input type=\"radio\" name=\"gender\" value=\"Female\">Female\r\n"
				+ "						<input type=\"radio\" name=\"gender\" value=\"Other\">Other\r\n"
				+ "                  </div>\r\n"
				+ "                  <div class=\"mt-3\">\r\n"
				+ "						<button class=\"btn btn-block btn-gradient-primary btn-lg font-weight-medium auth-form-btn\" type=\"submit\" name=\"register\">Register</button> \r\n"
				+ "                  </div>\r\n"
				+ "                  <div class=\"text-center mt-4 font-weight-light\"> Already have an account? <a href=\"login.html\" class=\"text-primary\">Login</a>\r\n"
				+ "                  </div>"
				+"				</form>"	
				+"				</div>\r\n"
				+ "            </div>\r\n"
				+ "          </div>\r\n"
				+ "        </div>\r\n"
				+ "        <!-- content-wrapper ends -->\r\n"
				+ "      </div>\r\n"
				+ "      <!-- page-body-wrapper ends -->\r\n"
				+ "    </div>\r\n"
				+ "    <!-- container-scroller -->\r\n"
				+ "    <!-- plugins:js -->\r\n"
				+ "    <script src=\"./assets/vendors/js/vendor.bundle.base.js\"></script>\r\n"
				+ "    <!-- endinject -->\r\n"
				+ "    <!-- Plugin js for this page -->\r\n"
				+ "    <!-- End plugin js for this page -->\r\n"
				+ "    <!-- inject:js -->\r\n"
				+ "    <script src=\"./assets/js/off-canvas.js\"></script>\r\n"
				+ "    <script src=\"./assets/js/hoverable-collapse.js\"></script>\r\n"
				+ "    <script src=\"./assets/js/misc.js\"></script>\r\n"
				+ "    <!-- endinject -->\r\n"
				+ "  </body>\r\n"
				+ "</html>"
				);
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
