package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.AccountType;
import org.cap.model.Customer;
import org.cap.service.WalletService;
import org.cap.service.WalletServiceImpl;

/**
 * Servlet implementation class DepWdServlet
 */
@WebServlet("/DepWdServlet")
public class DepWdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private WalletService walletService;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DepWdServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		walletService = new WalletServiceImpl();
		String amt = request.getParameter("balance");
		double amount = Double.parseDouble(amt);  
		String type = request.getParameter("atype");
		
		HttpSession httpSession = request.getSession(true);
		int customerId1 = (int) httpSession.getAttribute("customerId");
		int customerId = Integer.parseInt(httpSession.getAttribute("customerId").toString()) ;
		String customerName=httpSession.getAttribute("customerName").toString();

		int accountno = Integer.parseInt(request.getParameter("account"));
		String transactiontype = request.getParameter("transactiontype");

		Customer customer = walletService.findCustomer(customerId);
		Account account = walletService.findAccount(accountno);
		List<Account> accounts = walletService.finAccountsByCustomer(customer,"from");
		
		Account account1 = walletService.transaction(accountno, amount, transactiontype);
		
		response.sendRedirect("MainPageServlet");
		
	
	}

}
