package org.cap.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.TransactionType;
import org.cap.service.WalletService;
import org.cap.service.WalletServiceImpl;

/**
 * Servlet implementation class TransferServlet
 */
@WebServlet("/TransferServlet")
public class TransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private WalletService walletService;

       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TransferServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		walletService = new WalletServiceImpl();
		

		HttpSession httpSession=request.getSession(true);
		int customerId = (int) httpSession.getAttribute("customerId");
		String customerName=httpSession.getAttribute("customerName").toString();
		
		double amount = Double.parseDouble(request.getParameter("balance"));
		
		int fromAccount=Integer.parseInt(request.getParameter("sAcc"));
		int to_account = Integer.parseInt(request.getParameter("rAcc"));
		
		Account Acinfo = walletService.findAccount(fromAccount);
		
		if(Acinfo.getBalance() > amount) {
			Account account = walletService.transaction(fromAccount, amount, "withdraw");
			Account account1 = walletService.transaction(to_account, amount, "deposit");
			//response.sendRedirect("MainPageServlet");

		}
		response.sendRedirect("MainPageServlet");
		//request.getRequestDispatcher("/MainpageServlet").include(request, response);


		

		
	}

}
