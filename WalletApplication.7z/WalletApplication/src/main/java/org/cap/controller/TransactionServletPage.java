package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.service.WalletService;
import org.cap.service.WalletServiceImpl;

/**
 * Servlet implementation class TransactionServletPage
 */
@WebServlet("/TransactionServletPage")
public class TransactionServletPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private WalletService walletService;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public TransactionServletPage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		walletService = new WalletServiceImpl();

		HttpSession httpSession=request.getSession(true);
		int customerId = (int) httpSession.getAttribute("customerId");
		String customerName=httpSession.getAttribute("customerName").toString();

		Customer customer = walletService.findCustomer(customerId);
		List<Account> accounts = walletService.finAccountsByCustomer(customer,"from");

		PrintWriter printWriter=response.getWriter();
		printWriter.println("<!DOCTYPE html>\r\n"
				+ "<html lang=\"en\">\r\n"
				+ "<head>\r\n"
				+ "<!-- Required meta tags -->\r\n"
				+ "<meta charset=\"utf-8\">\r\n"
				+ "<meta name=\"viewport\"\r\n"
				+ "	content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">\r\n"
				+ "<title>Purple Admin</title>\r\n"
				+ "<!-- plugins:css -->\r\n"
				+ "<link rel=\"stylesheet\"\r\n"
				+ "	href=\"./assets/vendors/mdi/css/materialdesignicons.min.css\">\r\n"
				+ "<link rel=\"stylesheet\"\r\n"
				+ "	href=\"./assets/vendors/css/vendor.bundle.base.css\">\r\n"
				+ "<!-- endinject -->\r\n"
				+ "<!-- Plugin css for this page -->\r\n"
				+ "<!-- End plugin css for this page -->\r\n"
				+ "<!-- inject:css -->\r\n"
				+ "<!-- endinject -->\r\n"
				+ "<!-- Layout styles -->\r\n"
				+ "<link rel=\"stylesheet\" href=\"./assets/css/style.css\">\r\n"
				+ "<!-- End layout styles -->\r\n"
				+ "<link rel=\"shortcut icon\" href=\"./assets/images/favicon.ico\" />\r\n"
				+ "</head>\r\n"
				+ "<body>\r\n"
				+ "	<div class=\"container-scroller\">\r\n"
				+ "\r\n"
				+ "		<!-- partial:partials/_navbar.html -->\r\n"
				+ "		<nav\r\n"
				+ "			class=\"navbar default-layout-navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row\">\r\n"
				+ "			<div\r\n"
				+ "				class=\"text-center navbar-brand-wrapper d-flex align-items-center justify-content-center\">\r\n"
				+ "				<a class=\"navbar-brand brand-logo\" href=\"index.html\"><img\r\n"
				+ "					src=\"./assets/images/logo.svg\" alt=\"logo\" /></a> <a\r\n"
				+ "					class=\"navbar-brand brand-logo-mini\" href=\"index.html\"><img\r\n"
				+ "					src=\"./assets/images/logo-mini.svg\" alt=\"logo\" /></a>\r\n"
				+ "			</div>\r\n"
				+ "			<div class=\"navbar-menu-wrapper d-flex align-items-stretch\">\r\n"
				+ "				<button class=\"navbar-toggler navbar-toggler align-self-center\"\r\n"
				+ "					type=\"button\" data-toggle=\"minimize\">\r\n"
				+ "					<span class=\"mdi mdi-menu\"></span>\r\n"
				+ "				</button>\r\n"
				+ "\r\n"
				+ "				<ul class=\"navbar-nav navbar-nav-right\">\r\n"
				+ "					<li class=\"nav-item nav-profile dropdown\">\r\n"
				+ "						<div class=\"nav-profile-text\">\r\n"
				+ "							<p class=\"mb-1 text-black\">"+customerName+"</p>\r\n"
				+ "						</div>\r\n"
				+ "					</li>\r\n"
				+ "					<li class=\"nav-item d-none d-lg-block full-screen-link\"><a\r\n"
				+ "						class=\"nav-link\"> <i class=\"mdi mdi-fullscreen\"\r\n"
				+ "							id=\"fullscreen-button\"></i>\r\n"
				+ "					</a></li>\r\n"
				+ "\r\n"
				+ "					<li class=\"nav-item nav-logout d-none d-lg-block\"><a\r\n"
				+ "						class=\"nav-link\" href=\"./LogoutServlet\"> <i class=\"mdi mdi-power\"></i>\r\n"
				+ "					</a></li>\r\n"
				+ "					<li class=\"nav-item nav-settings d-none d-lg-block\"><a\r\n"
				+ "						class=\"nav-link\" href=\"#\"> <i\r\n"
				+ "							class=\"mdi mdi-format-line-spacing\"></i>\r\n"
				+ "					</a></li>\r\n"
				+ "				</ul>\r\n"
				+ "				<button\r\n"
				+ "					class=\"navbar-toggler navbar-toggler-right d-lg-none align-self-center\"\r\n"
				+ "					type=\"button\" data-toggle=\"offcanvas\">\r\n"
				+ "					<span class=\"mdi mdi-menu\"></span>\r\n"
				+ "				</button>\r\n"
				+ "			</div>\r\n"
				+ "		</nav>\r\n"
				+ "		<!-- partial -->\r\n"
				+ "		<div class=\"container-fluid page-body-wrapper\">\r\n"
				+ "			<!-- partial:partials/_sidebar.html -->\r\n"
				+ "			<nav class=\"sidebar sidebar-offcanvas\" id=\"sidebar\">\r\n"
				+ "				<ul class=\"nav\">\r\n"
				+ "\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\" href=\"./MainPageServlet\">\r\n"
				+ "							<span class=\"menu-title\">Dashboard</span> <i\r\n"
				+ "							class=\"mdi mdi-home menu-icon\"></i>\r\n"
				+ "					</a></li>\r\n"
				+ "\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"./CreateAccServletPage\"> <span class=\"menu-title\">Create\r\n"
				+ "								Account</span> <i class=\"mdi mdi-account-plus\r\n"
				+ "								 menu-icon\"></i>\r\n"
				+ "					</a></li>\r\n"
				+ "\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"./DepWdServletPage\"> <span class=\"menu-title\">Deposit</span>\r\n"
				+ "							<i class=\"mdi mdi-contacts menu-icon\"></i></a></li>\r\n"
				+ "\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"./TransferServletPage\"> <span class=\"menu-title\">Transfer</span>\r\n"
				+ "							<i class=\"mdi mdi-contacts menu-icon\"></i></a></li>\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "					<li class=\"nav-item\"><a class=\"nav-link\"\r\n"
				+ "						href=\"./TransactionServletPage\"> <span class=\"menu-title\">Transaction</span>\r\n"
				+ "						<i class=\"mdi mdi-contacts menu-icon\"></i></a></li>\r\n"
				+ "				</ul>\r\n"
				+ "			</nav>\r\n"
				+ "\r\n"
				+ "			<!-- partial -->\r\n"
				+ "			<div class=\"main-panel\">\r\n"
				+ "				<div class=\"content-wrapper\">\r\n"
				+ "					<div class=\"page-header\">\r\n"
				+ "						<h3 class=\"page-title\">\r\n"
				+ "							<span class=\"page-title-icon bg-gradient-primary text-white me-2\">\r\n"
				+ "								<i class=\"mdi mdi-home\"></i>\r\n"
				+ "							</span> Deposit\r\n"
				+ "						</h3>\r\n"
				+ "						<nav aria-label=\"breadcrumb\"></nav>\r\n"
				+ "					</div>\r\n"
				+ "\r\n"
				+ "					<!-- Main content Create Account Form -->\r\n"
				+ "					<div class=\"card\">\r\n"
				+ "						<div class=\"card-body\">\r\n"
				+ "							<h4 class=\"card-title\">Deposit And Withdraw</h4>\r\n"
				+ "\r\n"
				+ "							<form class=\"form-sample\" action=\"./TransactionListServlet\"\r\n"
				+ "								method=\"post\" modelAttribute=\"accountcreation\">\r\n"
				+ "								<div class=\"row\">\r\n"
				+ "									<div class=\"col-md-6\">\r\n"
				+ "										<label class=\"col-sm-3 col-form-label\">Start Date</label>\r\n"
				+ "										<div class=\"form-group row\">\r\n"
				+ "											<div class=\"col-sm-9\">\r\n"
				+ "												<input type=\"date\" name=\"start_date\" size=\"20\">\r\n"
				+ "											</div>\r\n"
				+ "										</div>\r\n"
				+ "									</div>\r\n"
				+ "									<div class=\"col-md-6\">\r\n"
				+ "										<label class=\"col-sm-4 col-form-label\">End Date</label>\r\n"
				+ "										<div class=\"form-group row\">\r\n"
				+ "											<div class=\"col-sm-9\">\r\n"
				+ "											<input type=\"date\" name=\"end_date\" size=\"20\">\r\n"
				+ "											</div>\r\n"
				+ "										</div>\r\n"
				+ "									</div>\r\n"
				+ "								</div>\r\n"
				+ "								<div class=\"row\">\r\n"
				+ "									<div class=\"col-md-6\">\r\n"
				+ "										<label class=\"col-sm-3 col-form-label\">Account Number</label>\r\n"
				+ "										<div class=\"form-group row\">\r\n"
				+ "											<div class=\"col-sm-9\">\r\n"
				+"												<select name=\"account\">"
				+ "													<option value=\"Select\">Select</option>");

																		for(Account account:accounts) {
																			printWriter.println("<option value="+account.getAccountNumber()+">"+account.getAccountNumber()+ " "+account.getAccountType()+"</option>");
																		}
																	
																printWriter.println("</select>\r\n"

				+ "											</div>\r\n"
				+ "										</div>\r\n"
				+ "									</div>\r\n"
				+ "									<div class=\"col-md-6\">\r\n"
				+ "										<label class=\"col-sm-4 col-form-label\"></label>\r\n"
				+ "										<div class=\"form-group row\">\r\n"
				+ "											<div class=\"col-sm-9\">\r\n"
				+ "												<button type=\"submit\" class=\"btn btn-primary btn-fw\"\r\n"
				+ "													value=Register>Submit</button>\r\n"
				+ "											</div>\r\n"
				+ "										</div>\r\n"
				+ "									</div>\r\n"
				+ "\r\n"
				+ "								</div>\r\n"
				+ "							</form>\r\n"
				+ "						</div>\r\n"
				+ "					</div>\r\n"
				+ "\r\n"
				+ "				</div>\r\n"
				+ "\r\n"
				+ "				\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "				<!-- partial:partials/_footer.html -->\r\n"
				+ "				<footer class=\"footer\">\r\n"
				+ "					<div class=\"container-fluid d-flex justify-content-between\">\r\n"
				+ "						<span\r\n"
				+ "							class=\"text-muted d-block text-center text-sm-start d-sm-inline-block\">Copyright\r\n"
				+ "							� Hussain</span>\r\n"
				+ "					</div>\r\n"
				+ "				</footer>\r\n"
				+ "				<!-- partial -->\r\n"
				+ "			</div>\r\n"
				+ "			<!-- main-panel ends -->\r\n"
				+ "		</div>\r\n"
				+ "		<!-- page-body-wrapper ends -->\r\n"
				+ "\r\n"
				+ "\r\n"
				+ "	</div>\r\n"
				+ "	<!-- container-scroller -->\r\n"
				+ "	<!-- plugins:js -->\r\n"
				+ "	<script src=\"./assets/vendors/js/vendor.bundle.base.js\"></script>\r\n"
				+ "	<!-- endinject -->\r\n"
				+ "	<!-- Plugin js for this page -->\r\n"
				+ "	<script src=\"./assets/vendors/chart.js/Chart.min.js\"></script>\r\n"
				+ "	<script src=\"./assets/js/jquery.cookie.js\" type=\"text/javascript\"></script>\r\n"
				+ "	<!-- End plugin js for this page -->\r\n"
				+ "	<!-- inject:js -->\r\n"
				+ "	<script src=\"./assets/js/off-canvas.js\"></script>\r\n"
				+ "	<script src=\"./assets/js/hoverable-collapse.js\"></script>\r\n"
				+ "	<script src=\"./assets/js/misc.js\"></script>\r\n"
				+ "	<!-- endinject -->\r\n"
				+ "	<!-- Custom js for this page -->\r\n"
				+ "	<script src=\"./assets/js/dashboard.js\"></script>\r\n"
				+ "	<script src=\"./assets/js/todolist.js\"></script>\r\n"
				+ "	<!-- End custom js for this page -->\r\n"
				+ "\r\n"
				+ "</body>\r\n"
				+ "</html>");
		
	}

}
